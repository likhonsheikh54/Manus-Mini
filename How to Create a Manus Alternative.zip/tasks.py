from flask import Blueprint, jsonify, request
from datetime import datetime, timedelta
import uuid
import threading
import time

tasks_bp = Blueprint('tasks', __name__)

# In-memory storage for demo purposes
active_tasks = {}
completed_tasks = {}
task_templates = [
    {
        'id': 'website_creation',
        'name': 'Website Creation',
        'description': 'Build a complete website with modern design',
        'estimated_duration': '30-60 minutes',
        'steps': [
            'Gather requirements',
            'Design layout',
            'Develop frontend',
            'Add content',
            'Test and optimize'
        ]
    },
    {
        'id': 'market_research',
        'name': 'Market Research',
        'description': 'Comprehensive competitor and market analysis',
        'estimated_duration': '20-40 minutes',
        'steps': [
            'Define research scope',
            'Gather data sources',
            'Analyze competitors',
            'Identify trends',
            'Generate report'
        ]
    },
    {
        'id': 'content_generation',
        'name': 'Content Generation',
        'description': 'Create blog posts, articles, and marketing copy',
        'estimated_duration': '15-30 minutes',
        'steps': [
            'Define content goals',
            'Research topics',
            'Create outline',
            'Write content',
            'Review and edit'
        ]
    }
]

@tasks_bp.route('/tasks/create', methods=['POST'])
def create_task():
    """Create a new task from user input"""
    try:
        data = request.json
        title = data.get('title', '')
        description = data.get('description', '')
        task_type = data.get('type', 'general')
        
        if not title.strip():
            return jsonify({'error': 'Task title is required'}), 400
        
        task_id = str(uuid.uuid4())
        
        task = {
            'id': task_id,
            'title': title,
            'description': description,
            'type': task_type,
            'status': 'created',
            'progress': 0,
            'current_step': 'Initializing...',
            'total_steps': 5,
            'created_at': datetime.now().isoformat(),
            'started_at': None,
            'estimated_completion': None,
            'logs': []
        }
        
        active_tasks[task_id] = task
        
        # Start task execution in background
        threading.Thread(target=simulate_task_execution, args=(task_id,), daemon=True).start()
        
        return jsonify({
            'task': task,
            'status': 'created'
        }), 201
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@tasks_bp.route('/tasks/list', methods=['GET'])
def list_tasks():
    """List all tasks with optional filtering"""
    try:
        status_filter = request.args.get('status')  # 'active', 'completed', 'all'
        task_type = request.args.get('type')
        limit = int(request.args.get('limit', 50))
        
        tasks = []
        
        if status_filter != 'completed':
            tasks.extend(list(active_tasks.values()))
        
        if status_filter != 'active':
            tasks.extend(list(completed_tasks.values()))
        
        # Filter by type if specified
        if task_type:
            tasks = [task for task in tasks if task.get('type') == task_type]
        
        # Sort by creation date (most recent first)
        tasks.sort(key=lambda x: x['created_at'], reverse=True)
        
        # Apply limit
        tasks = tasks[:limit]
        
        return jsonify({
            'tasks': tasks,
            'total_count': len(tasks),
            'active_count': len(active_tasks),
            'completed_count': len(completed_tasks)
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@tasks_bp.route('/tasks/<task_id>/status', methods=['GET'])
def get_task_status(task_id):
    """Get detailed status of a specific task"""
    try:
        task = active_tasks.get(task_id) or completed_tasks.get(task_id)
        
        if not task:
            return jsonify({'error': 'Task not found'}), 404
        
        return jsonify({
            'task': task,
            'is_active': task_id in active_tasks
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@tasks_bp.route('/tasks/<task_id>/cancel', methods=['POST'])
def cancel_task(task_id):
    """Cancel a running task"""
    try:
        if task_id not in active_tasks:
            return jsonify({'error': 'Task not found or not active'}), 404
        
        task = active_tasks[task_id]
        task['status'] = 'cancelled'
        task['completed_at'] = datetime.now().isoformat()
        task['logs'].append({
            'timestamp': datetime.now().isoformat(),
            'message': 'Task cancelled by user',
            'level': 'info'
        })
        
        # Move to completed tasks
        completed_tasks[task_id] = task
        del active_tasks[task_id]
        
        return jsonify({
            'task': task,
            'status': 'cancelled'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@tasks_bp.route('/tasks/<task_id>/pause', methods=['POST'])
def pause_task(task_id):
    """Pause or resume a task"""
    try:
        if task_id not in active_tasks:
            return jsonify({'error': 'Task not found or not active'}), 404
        
        task = active_tasks[task_id]
        
        if task['status'] == 'running':
            task['status'] = 'paused'
            task['paused_at'] = datetime.now().isoformat()
            message = 'Task paused'
        elif task['status'] == 'paused':
            task['status'] = 'running'
            task['resumed_at'] = datetime.now().isoformat()
            message = 'Task resumed'
        else:
            return jsonify({'error': 'Task cannot be paused in current state'}), 400
        
        task['logs'].append({
            'timestamp': datetime.now().isoformat(),
            'message': message,
            'level': 'info'
        })
        
        return jsonify({
            'task': task,
            'status': task['status']
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@tasks_bp.route('/tasks/templates', methods=['GET'])
def get_task_templates():
    """Get available task templates"""
    try:
        return jsonify({
            'templates': task_templates,
            'total_count': len(task_templates)
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@tasks_bp.route('/tasks/templates/<template_id>/create', methods=['POST'])
def create_task_from_template(template_id):
    """Create a task from a template"""
    try:
        template = next((t for t in task_templates if t['id'] == template_id), None)
        
        if not template:
            return jsonify({'error': 'Template not found'}), 404
        
        data = request.json or {}
        
        task_id = str(uuid.uuid4())
        
        task = {
            'id': task_id,
            'title': data.get('title', template['name']),
            'description': data.get('description', template['description']),
            'type': template['id'],
            'status': 'created',
            'progress': 0,
            'current_step': 'Initializing...',
            'total_steps': len(template['steps']),
            'steps': template['steps'],
            'created_at': datetime.now().isoformat(),
            'started_at': None,
            'estimated_completion': None,
            'logs': []
        }
        
        active_tasks[task_id] = task
        
        # Start task execution in background
        threading.Thread(target=simulate_task_execution, args=(task_id,), daemon=True).start()
        
        return jsonify({
            'task': task,
            'template': template,
            'status': 'created'
        }), 201
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def simulate_task_execution(task_id):
    """Simulate task execution with progress updates"""
    try:
        if task_id not in active_tasks:
            return
        
        task = active_tasks[task_id]
        task['status'] = 'running'
        task['started_at'] = datetime.now().isoformat()
        
        steps = task.get('steps', ['Step 1', 'Step 2', 'Step 3', 'Step 4', 'Step 5'])
        total_steps = len(steps)
        
        for i, step in enumerate(steps):
            if task_id not in active_tasks or task['status'] != 'running':
                break
            
            # Update progress
            progress = int((i + 1) / total_steps * 100)
            task['progress'] = progress
            task['current_step'] = step
            
            # Add log entry
            task['logs'].append({
                'timestamp': datetime.now().isoformat(),
                'message': f'Started: {step}',
                'level': 'info'
            })
            
            # Simulate work time (2-8 seconds per step)
            time.sleep(2 + (i * 1.5))
            
            # Check if task was paused
            while task.get('status') == 'paused':
                time.sleep(1)
                if task_id not in active_tasks:
                    return
        
        # Complete the task
        if task_id in active_tasks and task['status'] == 'running':
            task['status'] = 'completed'
            task['progress'] = 100
            task['current_step'] = 'Completed'
            task['completed_at'] = datetime.now().isoformat()
            
            task['logs'].append({
                'timestamp': datetime.now().isoformat(),
                'message': 'Task completed successfully',
                'level': 'success'
            })
            
            # Move to completed tasks
            completed_tasks[task_id] = task
            del active_tasks[task_id]
            
    except Exception as e:
        if task_id in active_tasks:
            task = active_tasks[task_id]
            task['status'] = 'error'
            task['error'] = str(e)
            task['completed_at'] = datetime.now().isoformat()
            
            task['logs'].append({
                'timestamp': datetime.now().isoformat(),
                'message': f'Task failed: {str(e)}',
                'level': 'error'
            })
            
            completed_tasks[task_id] = task
            del active_tasks[task_id]

