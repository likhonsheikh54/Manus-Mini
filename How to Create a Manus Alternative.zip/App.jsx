import { useState, useEffect } from 'react'
import Header from './components/Header.jsx'
import ChatPanel from './components/ChatPanel.jsx'
import BrowserView from './components/BrowserView.jsx'
import TaskPanel from './components/TaskPanel.jsx'
import StatusBar from './components/StatusBar.jsx'
import './App.css'

function App() {
  const [darkMode, setDarkMode] = useState(false)

  useEffect(() => {
    // Check for saved theme preference or default to light mode
    const savedTheme = localStorage.getItem('theme')
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches
    
    if (savedTheme === 'dark' || (!savedTheme && prefersDark)) {
      setDarkMode(true)
      document.documentElement.classList.add('dark')
    }
  }, [])

  const toggleDarkMode = () => {
    setDarkMode(!darkMode)
    if (!darkMode) {
      document.documentElement.classList.add('dark')
      localStorage.setItem('theme', 'dark')
    } else {
      document.documentElement.classList.remove('dark')
      localStorage.setItem('theme', 'light')
    }
  }

  return (
    <div className="h-screen flex flex-col bg-background">
      <Header darkMode={darkMode} toggleDarkMode={toggleDarkMode} />
      
      <main className="flex-1 flex gap-4 p-4 min-h-0">
        {/* Chat Panel */}
        <div className="w-1/3 min-w-[350px]">
          <ChatPanel />
        </div>
        
        {/* Browser View */}
        <div className="flex-1 min-w-[400px]">
          <BrowserView />
        </div>
        
        {/* Task Panel */}
        <div className="w-1/3 min-w-[300px]">
          <TaskPanel />
        </div>
      </main>
      
      <StatusBar />
    </div>
  )
}

export default App
