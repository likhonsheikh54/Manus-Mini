from flask import Blueprint, jsonify, request
from datetime import datetime
import base64
import io
import time

browser_bp = Blueprint('browser', __name__)

# In-memory storage for browser state
browser_state = {
    'current_url': 'about:blank',
    'is_loading': False,
    'takeover_mode': False,
    'recording': False,
    'action_log': [],
    'screenshots': []
}

@browser_bp.route('/browser/navigate', methods=['POST'])
def navigate():
    """Navigate to a URL"""
    try:
        data = request.json
        url = data.get('url', '')
        
        if not url:
            return jsonify({'error': 'URL is required'}), 400
        
        # Simulate navigation
        browser_state['is_loading'] = True
        browser_state['current_url'] = url
        
        # Add to action log
        action = {
            'id': len(browser_state['action_log']) + 1,
            'action': f'Navigated to {url}',
            'timestamp': datetime.now().isoformat(),
            'status': 'pending',
            'url': url
        }
        browser_state['action_log'].append(action)
        
        # Simulate loading time
        import threading
        def complete_navigation():
            time.sleep(2)  # Simulate loading
            browser_state['is_loading'] = False
            action['status'] = 'completed'
            action['completed_at'] = datetime.now().isoformat()
        
        threading.Thread(target=complete_navigation, daemon=True).start()
        
        return jsonify({
            'status': 'success',
            'url': url,
            'action': action,
            'browser_state': get_browser_state()
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@browser_bp.route('/browser/action', methods=['POST'])
def execute_action():
    """Execute a browser action (click, type, etc.)"""
    try:
        data = request.json
        action_type = data.get('type', '')
        target = data.get('target', '')
        value = data.get('value', '')
        
        if not action_type:
            return jsonify({'error': 'Action type is required'}), 400
        
        # Create action log entry
        action_description = f"{action_type.title()}"
        if target:
            action_description += f" '{target}'"
        if value:
            action_description += f" with value '{value}'"
        
        action = {
            'id': len(browser_state['action_log']) + 1,
            'action': action_description,
            'timestamp': datetime.now().isoformat(),
            'status': 'completed',
            'type': action_type,
            'target': target,
            'value': value
        }
        
        browser_state['action_log'].append(action)
        
        return jsonify({
            'status': 'success',
            'action': action,
            'browser_state': get_browser_state()
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@browser_bp.route('/browser/screenshot', methods=['GET'])
def take_screenshot():
    """Take a screenshot of the current page"""
    try:
        # Simulate screenshot (in production, use actual browser automation)
        screenshot_data = generate_mock_screenshot()
        
        screenshot = {
            'id': len(browser_state['screenshots']) + 1,
            'timestamp': datetime.now().isoformat(),
            'url': browser_state['current_url'],
            'data': screenshot_data,
            'format': 'png'
        }
        
        browser_state['screenshots'].append(screenshot)
        
        # Add to action log
        action = {
            'id': len(browser_state['action_log']) + 1,
            'action': 'Screenshot captured',
            'timestamp': datetime.now().isoformat(),
            'status': 'completed'
        }
        browser_state['action_log'].append(action)
        
        return jsonify({
            'status': 'success',
            'screenshot': screenshot,
            'action': action
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@browser_bp.route('/browser/takeover', methods=['POST'])
def toggle_takeover():
    """Enable or disable user takeover mode"""
    try:
        data = request.json
        enable = data.get('enable', not browser_state['takeover_mode'])
        
        browser_state['takeover_mode'] = enable
        
        action = {
            'id': len(browser_state['action_log']) + 1,
            'action': f"{'Enabled' if enable else 'Disabled'} user takeover",
            'timestamp': datetime.now().isoformat(),
            'status': 'completed'
        }
        browser_state['action_log'].append(action)
        
        return jsonify({
            'status': 'success',
            'takeover_mode': enable,
            'action': action,
            'browser_state': get_browser_state()
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@browser_bp.route('/browser/recording', methods=['POST'])
def toggle_recording():
    """Start or stop recording browser actions"""
    try:
        data = request.json
        enable = data.get('enable', not browser_state['recording'])
        
        browser_state['recording'] = enable
        
        action = {
            'id': len(browser_state['action_log']) + 1,
            'action': f"{'Started' if enable else 'Stopped'} recording",
            'timestamp': datetime.now().isoformat(),
            'status': 'completed'
        }
        browser_state['action_log'].append(action)
        
        return jsonify({
            'status': 'success',
            'recording': enable,
            'action': action,
            'browser_state': get_browser_state()
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@browser_bp.route('/browser/state', methods=['GET'])
def get_browser_state_endpoint():
    """Get current browser state"""
    try:
        return jsonify({
            'status': 'success',
            'browser_state': get_browser_state()
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@browser_bp.route('/browser/actions', methods=['GET'])
def get_action_log():
    """Get browser action log"""
    try:
        limit = int(request.args.get('limit', 50))
        
        # Get most recent actions
        recent_actions = browser_state['action_log'][-limit:] if browser_state['action_log'] else []
        
        return jsonify({
            'status': 'success',
            'actions': recent_actions,
            'total_count': len(browser_state['action_log'])
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@browser_bp.route('/browser/clear', methods=['DELETE'])
def clear_browser_data():
    """Clear browser action log and screenshots"""
    try:
        data_type = request.args.get('type', 'all')  # 'actions', 'screenshots', 'all'
        
        if data_type in ['actions', 'all']:
            browser_state['action_log'] = []
        
        if data_type in ['screenshots', 'all']:
            browser_state['screenshots'] = []
        
        return jsonify({
            'status': 'success',
            'message': f'Cleared {data_type} data',
            'browser_state': get_browser_state()
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def get_browser_state():
    """Get current browser state summary"""
    return {
        'current_url': browser_state['current_url'],
        'is_loading': browser_state['is_loading'],
        'takeover_mode': browser_state['takeover_mode'],
        'recording': browser_state['recording'],
        'action_count': len(browser_state['action_log']),
        'screenshot_count': len(browser_state['screenshots']),
        'last_action': browser_state['action_log'][-1] if browser_state['action_log'] else None
    }

def generate_mock_screenshot():
    """Generate a mock screenshot (base64 encoded)"""
    # In production, this would capture an actual screenshot
    # For demo purposes, return a simple base64 encoded placeholder
    
    # Create a simple 1x1 pixel PNG
    import struct
    
    def create_png_pixel(r, g, b, a=255):
        # PNG signature
        png_signature = b'\x89PNG\r\n\x1a\n'
        
        # IHDR chunk
        width = height = 1
        ihdr_data = struct.pack('>IIBBBBB', width, height, 8, 6, 0, 0, 0)  # RGBA
        ihdr_crc = 0x7d8db8d3  # Pre-calculated CRC for 1x1 RGBA
        ihdr_chunk = struct.pack('>I', 13) + b'IHDR' + ihdr_data + struct.pack('>I', ihdr_crc)
        
        # IDAT chunk (pixel data)
        pixel_data = struct.pack('BBBB', r, g, b, a)
        compressed_data = b'\x78\x9c\x62\x00\x02\x00\x00\x05\x00\x01'  # Minimal zlib compression
        idat_crc = 0x35af061e  # Pre-calculated CRC
        idat_chunk = struct.pack('>I', len(compressed_data)) + b'IDAT' + compressed_data + struct.pack('>I', idat_crc)
        
        # IEND chunk
        iend_crc = 0xae426082  # Pre-calculated CRC
        iend_chunk = struct.pack('>I', 0) + b'IEND' + struct.pack('>I', iend_crc)
        
        return png_signature + ihdr_chunk + idat_chunk + iend_chunk
    
    # Create a blue pixel (simulating a screenshot)
    png_data = create_png_pixel(100, 150, 255)
    
    return base64.b64encode(png_data).decode('utf-8')

