from flask import Blueprint, jsonify, request
from datetime import datetime
import json
import os

chat_bp = Blueprint('chat', __name__)

# In-memory storage for demo purposes (in production, use a database)
chat_history = []
chat_sessions = {}

@chat_bp.route('/chat/message', methods=['POST'])
def send_message():
    """Send a new message to the AI agent"""
    try:
        data = request.json
        user_message = data.get('message', '')
        session_id = data.get('session_id', 'default')
        
        if not user_message.strip():
            return jsonify({'error': 'Message cannot be empty'}), 400
        
        # Create user message
        user_msg = {
            'id': len(chat_history) + 1,
            'type': 'user',
            'content': user_message,
            'timestamp': datetime.now().isoformat(),
            'session_id': session_id
        }
        
        chat_history.append(user_msg)
        
        # Simulate AI response (in production, integrate with actual AI service)
        ai_response = generate_ai_response(user_message)
        
        ai_msg = {
            'id': len(chat_history) + 1,
            'type': 'agent',
            'content': ai_response['content'],
            'timestamp': datetime.now().isoformat(),
            'session_id': session_id,
            'task_progress': ai_response.get('task_progress'),
            'task_id': ai_response.get('task_id')
        }
        
        chat_history.append(ai_msg)
        
        return jsonify({
            'user_message': user_msg,
            'agent_response': ai_msg,
            'status': 'success'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@chat_bp.route('/chat/history', methods=['GET'])
def get_chat_history():
    """Retrieve chat history for a session"""
    try:
        session_id = request.args.get('session_id', 'default')
        limit = int(request.args.get('limit', 50))
        
        # Filter messages by session_id
        session_messages = [
            msg for msg in chat_history 
            if msg.get('session_id') == session_id
        ]
        
        # Return most recent messages
        recent_messages = session_messages[-limit:] if session_messages else []
        
        return jsonify({
            'messages': recent_messages,
            'total_count': len(session_messages),
            'session_id': session_id
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@chat_bp.route('/chat/clear', methods=['DELETE'])
def clear_chat():
    """Clear chat history for a session"""
    try:
        session_id = request.args.get('session_id', 'default')
        
        global chat_history
        chat_history = [
            msg for msg in chat_history 
            if msg.get('session_id') != session_id
        ]
        
        return jsonify({
            'message': f'Chat history cleared for session {session_id}',
            'status': 'success'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@chat_bp.route('/chat/sessions', methods=['GET'])
def get_chat_sessions():
    """Get list of chat sessions"""
    try:
        sessions = {}
        for msg in chat_history:
            session_id = msg.get('session_id', 'default')
            if session_id not in sessions:
                sessions[session_id] = {
                    'session_id': session_id,
                    'message_count': 0,
                    'last_activity': msg['timestamp'],
                    'created_at': msg['timestamp']
                }
            sessions[session_id]['message_count'] += 1
            sessions[session_id]['last_activity'] = msg['timestamp']
        
        return jsonify({
            'sessions': list(sessions.values()),
            'total_sessions': len(sessions)
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def generate_ai_response(user_message):
    """Generate AI response based on user message (simplified simulation)"""
    message_lower = user_message.lower()
    
    # Task-related responses
    if any(keyword in message_lower for keyword in ['create', 'build', 'make', 'develop']):
        if 'website' in message_lower or 'landing page' in message_lower:
            return {
                'content': "I'll help you create a professional website. Let me break this down into steps:\n\n1. Gather requirements and content\n2. Design the layout and structure\n3. Develop the HTML/CSS/JavaScript\n4. Add responsive design\n5. Test and optimize\n\nI'm starting to work on this now. What type of website do you need and who is your target audience?",
                'task_progress': 15,
                'task_id': 'website_creation_001'
            }
        elif 'app' in message_lower or 'application' in message_lower:
            return {
                'content': "I'll help you build an application. To get started, I need to understand:\n\n• What type of application (web, mobile, desktop)?\n• What's the main functionality?\n• Who are your target users?\n• Any specific technologies you prefer?\n\nOnce I have these details, I can create a development plan and start building.",
                'task_progress': 10,
                'task_id': 'app_development_001'
            }
    
    # Research-related responses
    elif any(keyword in message_lower for keyword in ['research', 'analyze', 'find', 'search']):
        return {
            'content': "I'll conduct thorough research on this topic. My research process includes:\n\n1. Gathering information from reliable sources\n2. Analyzing and synthesizing findings\n3. Identifying key insights and trends\n4. Organizing results in a comprehensive report\n\nI'm starting the research now and will provide regular updates on my progress.",
            'task_progress': 25,
            'task_id': 'research_task_001'
        }
    
    # General helpful responses
    elif any(keyword in message_lower for keyword in ['help', 'assist', 'support']):
        return {
            'content': "I'm here to help! I can assist you with a wide range of tasks including:\n\n• Web development and design\n• Research and analysis\n• Content creation\n• Data processing\n• Automation tasks\n• And much more!\n\nJust describe what you need, and I'll create a plan to accomplish it step by step."
        }
    
    # Default response
    else:
        return {
            'content': "I understand your request. Let me analyze what you need and create an action plan. Could you provide a bit more detail about what you'd like me to help you with? The more specific you are, the better I can assist you.",
            'task_progress': 5,
            'task_id': 'general_task_001'
        }

