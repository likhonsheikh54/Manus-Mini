import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { ScrollArea } from '@/components/ui/scroll-area.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { 
  Play, 
  Pause, 
  Square, 
  MoreHorizontal, 
  Plus, 
  Clock, 
  CheckCircle2, 
  AlertCircle,
  Zap,
  Search,
  FileText,
  Code,
  Globe
} from 'lucide-react'
import '../App.css'

const TaskPanel = () => {
  const [activeTasks, setActiveTasks] = useState([
    {
      id: 1,
      title: 'Creating Landing Page',
      description: 'Building a responsive landing page for SaaS startup',
      progress: 80,
      currentStep: 'Styling components',
      totalSteps: 5,
      status: 'running',
      type: 'web-development',
      estimatedTime: '5 min',
      startTime: new Date(Date.now() - 600000)
    },
    {
      id: 2,
      title: 'Research Competitors',
      description: 'Analyzing competitor websites and features',
      progress: 20,
      currentStep: 'Gathering data',
      totalSteps: 4,
      status: 'running',
      type: 'research',
      estimatedTime: '12 min',
      startTime: new Date(Date.now() - 180000)
    }
  ])

  const [completedTasks, setCompletedTasks] = useState([
    {
      id: 3,
      title: 'Market Analysis Report',
      description: 'Generated comprehensive market analysis for project management tools',
      progress: 100,
      completedAt: new Date(Date.now() - 3600000),
      status: 'completed',
      type: 'research',
      duration: '15 min'
    },
    {
      id: 4,
      title: 'Logo Design Variations',
      description: 'Created 5 logo variations with different color schemes',
      progress: 100,
      completedAt: new Date(Date.now() - 7200000),
      status: 'completed',
      type: 'design',
      duration: '8 min'
    }
  ])

  const pauseTask = (taskId) => {
    setActiveTasks(prev => prev.map(task => 
      task.id === taskId 
        ? { ...task, status: task.status === 'paused' ? 'running' : 'paused' }
        : task
    ))
  }

  const cancelTask = (taskId) => {
    setActiveTasks(prev => prev.filter(task => task.id !== taskId))
  }

  const getTaskIcon = (type) => {
    switch (type) {
      case 'web-development': return <Code className="h-4 w-4" />
      case 'research': return <Search className="h-4 w-4" />
      case 'design': return <Zap className="h-4 w-4" />
      case 'content': return <FileText className="h-4 w-4" />
      case 'automation': return <Globe className="h-4 w-4" />
      default: return <Zap className="h-4 w-4" />
    }
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'running': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
      case 'paused': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200'
      case 'completed': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
      case 'error': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200'
    }
  }

  const formatTime = (timestamp) => {
    return timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  }

  const getElapsedTime = (startTime) => {
    const elapsed = Math.floor((Date.now() - startTime.getTime()) / 60000)
    return `${elapsed} min`
  }

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="flex-shrink-0 border-b">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">Task Management</CardTitle>
          <Button size="sm" className="gap-2">
            <Plus className="h-4 w-4" />
            New Task
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="flex-1 flex flex-col p-0">
        <Tabs defaultValue="active" className="flex-1 flex flex-col">
          <div className="border-b px-4 pt-4">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="active" className="gap-2">
                <Play className="h-4 w-4" />
                Active ({activeTasks.length})
              </TabsTrigger>
              <TabsTrigger value="completed" className="gap-2">
                <CheckCircle2 className="h-4 w-4" />
                Completed ({completedTasks.length})
              </TabsTrigger>
              <TabsTrigger value="templates" className="gap-2">
                <FileText className="h-4 w-4" />
                Templates
              </TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value="active" className="flex-1 m-0">
            <ScrollArea className="h-full">
              <div className="p-4 space-y-4">
                {activeTasks.map((task) => (
                  <Card key={task.id} className="border-l-4 border-l-blue-500">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-2">
                          {getTaskIcon(task.type)}
                          <h3 className="font-medium">{task.title}</h3>
                        </div>
                        <div className="flex items-center gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => pauseTask(task.id)}
                          >
                            {task.status === 'paused' ? 
                              <Play className="h-4 w-4" /> : 
                              <Pause className="h-4 w-4" />
                            }
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => cancelTask(task.id)}
                          >
                            <Square className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      
                      <p className="text-sm text-muted-foreground mb-3">
                        {task.description}
                      </p>
                      
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span>Progress</span>
                          <span>{task.progress}%</span>
                        </div>
                        <Progress value={task.progress} className="h-2" />
                        
                        <div className="flex items-center justify-between text-xs text-muted-foreground">
                          <span>Step {task.totalSteps - Math.floor((100 - task.progress) / (100 / task.totalSteps))}/{task.totalSteps}: {task.currentStep}</span>
                          <div className="flex items-center gap-4">
                            <div className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              <span>ETA: {task.estimatedTime}</span>
                            </div>
                            <Badge variant="outline" className={getStatusColor(task.status)}>
                              {task.status}
                            </Badge>
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between text-xs text-muted-foreground pt-1">
                          <span>Started: {formatTime(task.startTime)}</span>
                          <span>Running: {getElapsedTime(task.startTime)}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
                
                {activeTasks.length === 0 && (
                  <div className="text-center py-8">
                    <AlertCircle className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    <h3 className="font-medium mb-2">No Active Tasks</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Start a conversation with the AI agent to create new tasks.
                    </p>
                    <Button variant="outline">
                      <Plus className="h-4 w-4 mr-2" />
                      Create Task
                    </Button>
                  </div>
                )}
              </div>
            </ScrollArea>
          </TabsContent>
          
          <TabsContent value="completed" className="flex-1 m-0">
            <ScrollArea className="h-full">
              <div className="p-4 space-y-4">
                {completedTasks.map((task) => (
                  <Card key={task.id} className="border-l-4 border-l-green-500">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-2">
                          {getTaskIcon(task.type)}
                          <h3 className="font-medium">{task.title}</h3>
                        </div>
                        <div className="flex items-center gap-1">
                          <CheckCircle2 className="h-4 w-4 text-green-600" />
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      
                      <p className="text-sm text-muted-foreground mb-3">
                        {task.description}
                      </p>
                      
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <span>Completed: {formatTime(task.completedAt)}</span>
                        <div className="flex items-center gap-4">
                          <span>Duration: {task.duration}</span>
                          <Badge variant="outline" className={getStatusColor(task.status)}>
                            {task.status}
                          </Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>
          
          <TabsContent value="templates" className="flex-1 m-0">
            <ScrollArea className="h-full">
              <div className="p-4 space-y-4">
                <div className="grid gap-3">
                  {[
                    { name: 'Website Creation', description: 'Build a complete website with modern design', icon: <Globe className="h-4 w-4" /> },
                    { name: 'Market Research', description: 'Comprehensive competitor and market analysis', icon: <Search className="h-4 w-4" /> },
                    { name: 'Content Generation', description: 'Create blog posts, articles, and marketing copy', icon: <FileText className="h-4 w-4" /> },
                    { name: 'Code Development', description: 'Build applications and scripts', icon: <Code className="h-4 w-4" /> },
                    { name: 'Design Creation', description: 'Generate logos, graphics, and visual assets', icon: <Zap className="h-4 w-4" /> }
                  ].map((template, index) => (
                    <Card key={index} className="cursor-pointer hover:bg-muted/50 transition-colors">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="p-2 bg-primary/10 rounded-lg">
                            {template.icon}
                          </div>
                          <div className="flex-1">
                            <h3 className="font-medium text-sm">{template.name}</h3>
                            <p className="text-xs text-muted-foreground">{template.description}</p>
                          </div>
                          <Button variant="ghost" size="sm">
                            Use Template
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

export default TaskPanel

