import { useState, useEffect } from 'react'
import { Badge } from '@/components/ui/badge.jsx'
import { 
  Activity, 
  Cpu, 
  HardDrive, 
  Wifi, 
  Clock,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react'
import '../App.css'

const StatusBar = () => {
  const [systemStats, setSystemStats] = useState({
    cpuUsage: 45,
    memoryUsage: 62,
    diskUsage: 78,
    uptime: '2h 34m'
  })
  
  const [connectionStatus, setConnectionStatus] = useState('connected')
  const [activeTasks, setActiveTasks] = useState(2)
  const [completedTasks, setCompletedTasks] = useState(15)
  const [currentTime, setCurrentTime] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
      
      // Simulate system stats updates
      setSystemStats(prev => ({
        ...prev,
        cpuUsage: Math.max(20, Math.min(80, prev.cpuUsage + (Math.random() - 0.5) * 10)),
        memoryUsage: Math.max(30, Math.min(90, prev.memoryUsage + (Math.random() - 0.5) * 5))
      }))
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  const getStatusColor = (status) => {
    switch (status) {
      case 'connected': return 'text-green-600'
      case 'connecting': return 'text-yellow-600'
      case 'disconnected': return 'text-red-600'
      default: return 'text-gray-600'
    }
  }

  const getUsageColor = (usage) => {
    if (usage < 50) return 'text-green-600'
    if (usage < 80) return 'text-yellow-600'
    return 'text-red-600'
  }

  const formatTime = (date) => {
    return date.toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit',
      second: '2-digit'
    })
  }

  return (
    <footer className="border-t bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="flex h-8 items-center justify-between px-6 text-xs">
        {/* Left Section - Connection and Tasks */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1">
            <Wifi className={`h-3 w-3 ${getStatusColor(connectionStatus)}`} />
            <span className="capitalize">{connectionStatus}</span>
          </div>
          
          <div className="flex items-center gap-1">
            <Activity className="h-3 w-3 text-blue-600" />
            <span>{activeTasks} active tasks</span>
          </div>
          
          <div className="flex items-center gap-1">
            <CheckCircle2 className="h-3 w-3 text-green-600" />
            <span>{completedTasks} completed</span>
          </div>
        </div>

        {/* Center Section - System Health */}
        <div className="hidden md:flex items-center gap-4">
          <div className="flex items-center gap-1">
            <Cpu className={`h-3 w-3 ${getUsageColor(systemStats.cpuUsage)}`} />
            <span>CPU: {systemStats.cpuUsage.toFixed(0)}%</span>
          </div>
          
          <div className="flex items-center gap-1">
            <HardDrive className={`h-3 w-3 ${getUsageColor(systemStats.memoryUsage)}`} />
            <span>Memory: {systemStats.memoryUsage.toFixed(0)}%</span>
          </div>
          
          <div className="flex items-center gap-1">
            <Clock className="h-3 w-3 text-gray-600" />
            <span>Uptime: {systemStats.uptime}</span>
          </div>
        </div>

        {/* Right Section - Time and Status */}
        <div className="flex items-center gap-4">
          <div className="hidden sm:flex items-center gap-2">
            <Badge variant="outline" className="text-xs py-0 px-2 h-5">
              Agent Ready
            </Badge>
          </div>
          
          <div className="flex items-center gap-1">
            <Clock className="h-3 w-3 text-gray-600" />
            <span className="font-mono">{formatTime(currentTime)}</span>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default StatusBar

