import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { ScrollArea } from '@/components/ui/scroll-area.jsx'
import { Separator } from '@/components/ui/separator.jsx'
import { 
  ArrowLeft, 
  ArrowRight, 
  RotateCcw, 
  Camera, 
  Hand, 
  Circle,
  Monitor,
  Maximize2,
  Play,
  Pause
} from 'lucide-react'
import '../App.css'

const BrowserView = () => {
  const [url, setUrl] = useState('https://example.com')
  const [isLoading, setIsLoading] = useState(false)
  const [isRecording, setIsRecording] = useState(false)
  const [takeoverMode, setTakeoverMode] = useState(false)
  const [actionLog, setActionLog] = useState([
    {
      id: 1,
      action: 'Navigated to example.com',
      timestamp: new Date(Date.now() - 300000),
      status: 'completed'
    },
    {
      id: 2,
      action: 'Clicked "Get Started" button',
      timestamp: new Date(Date.now() - 280000),
      status: 'completed'
    },
    {
      id: 3,
      action: 'Filled form field "email"',
      timestamp: new Date(Date.now() - 260000),
      status: 'completed'
    },
    {
      id: 4,
      action: 'Waiting for page load...',
      timestamp: new Date(Date.now() - 10000),
      status: 'pending'
    }
  ])

  const navigate = () => {
    setIsLoading(true)
    // Simulate navigation
    setTimeout(() => {
      setIsLoading(false)
      const newAction = {
        id: actionLog.length + 1,
        action: `Navigated to ${url}`,
        timestamp: new Date(),
        status: 'completed'
      }
      setActionLog(prev => [...prev, newAction])
    }, 2000)
  }

  const goBack = () => {
    const newAction = {
      id: actionLog.length + 1,
      action: 'Navigated back',
      timestamp: new Date(),
      status: 'completed'
    }
    setActionLog(prev => [...prev, newAction])
  }

  const goForward = () => {
    const newAction = {
      id: actionLog.length + 1,
      action: 'Navigated forward',
      timestamp: new Date(),
      status: 'completed'
    }
    setActionLog(prev => [...prev, newAction])
  }

  const refresh = () => {
    setIsLoading(true)
    setTimeout(() => {
      setIsLoading(false)
      const newAction = {
        id: actionLog.length + 1,
        action: 'Page refreshed',
        timestamp: new Date(),
        status: 'completed'
      }
      setActionLog(prev => [...prev, newAction])
    }, 1500)
  }

  const takeScreenshot = () => {
    const newAction = {
      id: actionLog.length + 1,
      action: 'Screenshot captured',
      timestamp: new Date(),
      status: 'completed'
    }
    setActionLog(prev => [...prev, newAction])
  }

  const toggleTakeover = () => {
    setTakeoverMode(!takeoverMode)
    const newAction = {
      id: actionLog.length + 1,
      action: takeoverMode ? 'Disabled user takeover' : 'Enabled user takeover',
      timestamp: new Date(),
      status: 'completed'
    }
    setActionLog(prev => [...prev, newAction])
  }

  const toggleRecording = () => {
    setIsRecording(!isRecording)
    const newAction = {
      id: actionLog.length + 1,
      action: isRecording ? 'Stopped recording' : 'Started recording',
      timestamp: new Date(),
      status: 'completed'
    }
    setActionLog(prev => [...prev, newAction])
  }

  const formatTime = (timestamp) => {
    return timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
      case 'pending': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200'
      case 'error': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200'
    }
  }

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="flex-shrink-0 border-b">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">Browser Automation</CardTitle>
          <div className="flex items-center gap-2">
            <Badge variant={takeoverMode ? "destructive" : "secondary"}>
              {takeoverMode ? "User Control" : "AI Control"}
            </Badge>
            {isRecording && (
              <Badge variant="destructive" className="animate-pulse">
                <Circle className="h-2 w-2 mr-1 fill-current" />
                Recording
              </Badge>
            )}
          </div>
        </div>
        
        {/* Browser Controls */}
        <div className="flex items-center gap-2 mt-4">
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="sm" onClick={goBack}>
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={goForward}>
              <ArrowRight className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={refresh} disabled={isLoading}>
              <RotateCcw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
            </Button>
          </div>
          
          <div className="flex-1 flex items-center gap-2">
            <Input
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && navigate()}
              placeholder="Enter URL..."
              className="flex-1"
            />
            <Button onClick={navigate} disabled={isLoading} size="sm">
              Go
            </Button>
          </div>
          
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="sm" onClick={takeScreenshot}>
              <Camera className="h-4 w-4" />
            </Button>
            <Button 
              variant={takeoverMode ? "destructive" : "ghost"} 
              size="sm" 
              onClick={toggleTakeover}
            >
              <Hand className="h-4 w-4" />
            </Button>
            <Button 
              variant={isRecording ? "destructive" : "ghost"} 
              size="sm" 
              onClick={toggleRecording}
            >
              {isRecording ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            </Button>
            <Button variant="ghost" size="sm">
              <Maximize2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="flex-1 flex flex-col p-0">
        {/* Browser Viewport */}
        <div className="flex-1 bg-white dark:bg-gray-900 border-b relative">
          <div className="absolute inset-0 flex items-center justify-center">
            {isLoading ? (
              <div className="flex flex-col items-center gap-4">
                <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
                <p className="text-sm text-muted-foreground">Loading page...</p>
              </div>
            ) : (
              <div className="w-full h-full bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-blue-950 dark:to-indigo-950 flex items-center justify-center relative">
                {/* Simulated webpage content */}
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8 max-w-md w-full mx-4">
                  <div className="text-center">
                    <Monitor className="h-12 w-12 mx-auto mb-4 text-primary" />
                    <h2 className="text-xl font-semibold mb-2">Example Website</h2>
                    <p className="text-muted-foreground mb-4">
                      This is a simulated browser view showing how the AI agent interacts with web pages.
                    </p>
                    <div className="space-y-2">
                      <Button className="w-full" variant="outline">
                        Get Started
                      </Button>
                      <Button className="w-full">
                        Learn More
                      </Button>
                    </div>
                  </div>
                </div>
                
                {/* Highlight overlay for AI interactions */}
                {!takeoverMode && (
                  <div className="absolute inset-0 pointer-events-none">
                    <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-32 h-10 border-2 border-red-500 rounded animate-pulse" />
                  </div>
                )}
                
                {takeoverMode && (
                  <div className="absolute top-4 left-4 bg-red-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                    User Control Active
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
        
        {/* Action Log */}
        <div className="h-48 border-t">
          <div className="p-3 border-b">
            <h3 className="font-medium text-sm">Action Log</h3>
          </div>
          <ScrollArea className="h-36">
            <div className="p-3 space-y-2">
              {actionLog.map((action, index) => (
                <div key={action.id} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${
                      action.status === 'completed' ? 'bg-green-500' :
                      action.status === 'pending' ? 'bg-yellow-500 animate-pulse' :
                      'bg-red-500'
                    }`} />
                    <span>{action.action}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className={`text-xs ${getStatusColor(action.status)}`}>
                      {action.status}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {formatTime(action.timestamp)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </div>
      </CardContent>
    </Card>
  )
}

export default BrowserView

