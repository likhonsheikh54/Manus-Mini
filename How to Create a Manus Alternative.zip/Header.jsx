import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu.jsx'
import { 
  Moon, 
  Sun, 
  Settings, 
  User, 
  LogOut, 
  HelpCircle,
  Zap,
  Activity,
  Wifi,
  WifiOff
} from 'lucide-react'
import '../App.css'

const Header = ({ darkMode, toggleDarkMode }) => {
  const [isConnected, setIsConnected] = useState(true)
  const [activeTasks, setActiveTasks] = useState(2)

  return (
    <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="flex h-16 items-center justify-between px-6">
        {/* Logo and Navigation */}
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Zap className="h-5 w-5 text-primary-foreground" />
            </div>
            <h1 className="text-xl font-bold">Manus Alternative</h1>
          </div>
          
          <nav className="hidden md:flex items-center gap-4">
            <Button variant="ghost" size="sm">
              Chat
            </Button>
            <Button variant="ghost" size="sm">
              Tasks
            </Button>
            <Button variant="ghost" size="sm">
              Browser
            </Button>
            <Button variant="ghost" size="sm">
              Files
            </Button>
          </nav>
        </div>

        {/* Status and Controls */}
        <div className="flex items-center gap-4">
          {/* Connection Status */}
          <div className="flex items-center gap-2">
            {isConnected ? (
              <div className="flex items-center gap-1 text-green-600">
                <Wifi className="h-4 w-4" />
                <span className="text-sm font-medium hidden sm:inline">Connected</span>
              </div>
            ) : (
              <div className="flex items-center gap-1 text-red-600">
                <WifiOff className="h-4 w-4" />
                <span className="text-sm font-medium hidden sm:inline">Disconnected</span>
              </div>
            )}
          </div>

          {/* Active Tasks */}
          {activeTasks > 0 && (
            <Badge variant="secondary" className="gap-1">
              <Activity className="h-3 w-3" />
              {activeTasks} active
            </Badge>
          )}

          {/* Theme Toggle */}
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleDarkMode}
            className="w-9 h-9 p-0"
          >
            {darkMode ? (
              <Sun className="h-4 w-4" />
            ) : (
              <Moon className="h-4 w-4" />
            )}
          </Button>

          {/* Settings */}
          <Button variant="ghost" size="sm" className="w-9 h-9 p-0">
            <Settings className="h-4 w-4" />
          </Button>

          {/* Help */}
          <Button variant="ghost" size="sm" className="w-9 h-9 p-0">
            <HelpCircle className="h-4 w-4" />
          </Button>

          {/* User Menu */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="w-9 h-9 p-0">
                <User className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel>My Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <User className="mr-2 h-4 w-4" />
                <span>Profile</span>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Settings className="mr-2 h-4 w-4" />
                <span>Settings</span>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <HelpCircle className="mr-2 h-4 w-4" />
                <span>Help & Support</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <LogOut className="mr-2 h-4 w-4" />
                <span>Log out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  )
}

export default Header

